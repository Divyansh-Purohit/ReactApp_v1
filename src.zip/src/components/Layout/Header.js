import { Fragment, useContext } from 'react';
import classes from './Header.module.css';
import CoverImage from '../../assets/CoverImage.PNG';
import CartContext from '../../store/cart-context';
import HeaderCartButton from './HeaderCartButton.js';

const Header = (props) => {

    return(
        <Fragment>
            <header className={ classes.header }>
                <h2>For the Foodie inside you!</h2>
                <HeaderCartButton onClick={props.onShowCart}/>
            </header>
            <div className={ classes['main-image'] }>
                <img src = { CoverImage } alt="Oops!"></img>
            </div>
        </Fragment>
    )
}
export default Header;