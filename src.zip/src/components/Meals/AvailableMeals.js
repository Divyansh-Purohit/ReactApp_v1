import classes from './AvailableMeals.module.css';
import MealItem from './MealItem/MealItem';

import Card from '../UI/Card';

const DUMMY_MEALS = [
    {
      id: 'm1',
      name: 'Grilled Fish Sandwich',
      description: 'Finest fish and veggies',
      price: 22.99,
    },
    {
      id: 'm2',
      name: 'Chole Bhature',
      description: 'Truly Indian!',
      price: 16.5,
    },
    {
      id: 'm3',
      name: 'Butter Chicken',
      description: 'Awesome Delight!',
      price: 12.99,
    },
    {
      id: 'm4',
      name: 'French Fries',
      description: 'Better enjoyed with Coke',
      price: 18.99,
    },
  ];


  const AvailableMeals = () => {
      const meals = DUMMY_MEALS.map(meal => {
            return (<MealItem 
                      id={ meal.id }
                      key={ meal.id }
                      name={ meal.name }
                      description={ meal.description }
                      price={ meal.price }
                    />
                  );
      });

      return(
          <section className={ classes.meals }>
              <Card>
                  <ul>
                      {meals}
                  </ul>
              </Card>
          </section>
      )
  }

  export default AvailableMeals;